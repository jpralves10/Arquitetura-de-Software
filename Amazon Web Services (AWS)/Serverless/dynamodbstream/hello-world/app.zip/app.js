
exports.lambdaHandler = async (event, context) => {

    console.log(event.Records)

    event.Records.array.forEach(element => {
        console.log(element.dynamodb)
    });    
};
